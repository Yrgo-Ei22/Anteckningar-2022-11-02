/********************************************************************************
* header.h: Inneh�ller diverse definitioner och deklarationer f�r implementering
*           av tillst�ndsmaskinen.
********************************************************************************/
#ifndef HEADER_H_
#define HEADER_H_

/* Inkluderingsdirektiv: */
#include <avr/io.h>        /* Inneh�ller information om I/O-register s�som DDRB och PORTB. */
#include <avr/interrupt.h> /* Inneh�ller information om avbrottsvektorer s�som PCINT0_vect. */

/* Makrodefinitioner: */
#define LED1 PORTB0 /* Lysdiod 1 ansluten till pin 8 / PORTB0. */
#define LED2 PORTB1 /* Lysdiod 2 ansluten till pin 9 / PORTB1. */
#define LED3 PORTB2 /* Lysdiod 3 ansluten till pin 10 / PORTB2. */

#define OPEN_BUTTON PORTB3  /* �ppna-knapp ansluten till pin 11 / PORTB3. */
#define CLOSE_BUTTON PORTB4 /* St�ng-knapp ansluten till pin 12 / PORTB4. */
#define LOCK_BUTTON PORTB5  /* L�s-knapp ansluten till pin 13 / PORTB5. */
#define RESET_BUTTON PORTD2 /* Reset-knapp ansluten till pin 2 / PORTD2. */

#define LED1_ON PORTB |= (1 << LED1) /* T�nder lysdiod 1 (indikerar �ppen d�rr). */
#define LED2_ON PORTB |= (1 << LED2) /* T�nder lysdiod 2 (indikerar st�ngd d�rr). */
#define LED3_ON PORTB |= (1 << LED3) /* T�nder lysdiod 3 (indikerar l�st d�rr). */

#define LED1_OFF PORTB &= ~(1 << LED1) /* Sl�cker lysdiod 1. */
#define LED2_OFF PORTB &= ~(1 << LED2) /* Sl�cker lysdiod 2. */
#define LED3_OFF PORTB &= ~(1 << LED3) /* Sl�cker lysdiod 3. */

#define LEDS_ON PORTB |= (1 << LED1) | (1 << LED2) | (1 << LED3)     /* T�nder lysdioderna (indikerar fel). */
#define LEDS_OFF PORTB &= ~((1 << LED1) | (1 << LED2) | (1 << LED3)) /* Sl�cker lysdioderna (anv�nds ej). */

#define OPEN_BUTTON_PRESSED (PINB & (1 << OPEN_BUTTON))   /* Indikerar nedtryckning av �ppna-knappen. */
#define CLOSE_BUTTON_PRESSED (PINB & (1 << CLOSE_BUTTON)) /* Indikerar nedtryckning av st�ng-knappen. */
#define LOCK_BUTTON_PRESSED (PINB & (1 << LOCK_BUTTON))   /* Indikerar nedtryckning av l�s-knappen. */
#define RESET_BUTTON_PRESSED (PIND & (1 << RESET_BUTTON)) /* Indikerar nedtryckning av reset-knappen. */

/********************************************************************************
* bool: Datatyp som indikerar sant eller falskt. Denna datatyp �r vanlig i
*       flertalet programmeringsspr�k. I C utg�r bool dock inte en primitiv
*       datatyp, men kan implementeras via en enumeration som h�r eller via
*       inkludering av standardbiblioteket stdbool.h (f�r C99 och senare).
********************************************************************************/
typedef enum { false, true } bool;

/********************************************************************************
* door_state: Datatyp f�r lagring av d�rrens aktuella tillst�nd.
********************************************************************************/
enum door_state 
{ 
   DOOR_STATE_OPEN, 
   DOOR_STATE_CLOSED, 
   DOOR_STATE_LOCKED, 
   DOOR_STATE_ERROR 
};

/********************************************************************************
* setup: Initierar mikrodatorn vid start.
********************************************************************************/
void setup(void);

/********************************************************************************
* fsm_reset: �terst�ller d�rren till startl�get, vilket �r st�ngt tillst�nd.
*            Lysdioderna uppdateras d�refter (endast lysdiod 2 h�lls t�nd).
********************************************************************************/
void fsm_reset(void); 

/********************************************************************************
* fsm_uppdate: Uppdaterar d�rrens tillst�nd utefter aktuellt tillst�nd samt
*              vilken tryckknapp som trycks ned. 
********************************************************************************/
void fsm_update(void);

/********************************************************************************
* fsm_set_output: Uppdaterar lysdioderna utefter aktuellt tillst�nd enligt nedan:
*
*                 - Om d�rren �r �ppen t�nds lysdiod 1, �vriga h�lls sl�ckta.
*                 - Om d�rren �r st�ngd t�nds lysdiod 2, �vriga h�lls sl�ckta.
*                 - Om d�rren �r l�st t�nds lysdiod 3, �vriga h�lls sl�ckta.
*                 - Vid feltillst�nd t�nds samtliga lysdioder. 
*                 - Vid icke definierat tillst�nd �terst�lls d�rren till 
*                   startl�get, vilket �r st�ngd.
********************************************************************************/
void fsm_set_output(void);

#endif /* HEADER_H_ */